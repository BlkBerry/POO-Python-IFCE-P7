# POO-Python-IFCE-P7
Matéria de Programação Orientada à Objeto

Projeto do 7o período do curso de Informática do IFCE.
